<?php
require 'baglan.php';
$UserName=$_POST['K_Adi'];
$Pass=$_POST['Sifre'];
$rePass=$_POST['re-Sifre'];

if ($Pass==$rePass) {
    if($ekle=mysqli_query($baglanti,"INSERT INTO kullanici(K_Adi,Sifre) 
    VALUES('$UserName','$Pass')")){
        $message = "Kayıt Olundu";
    echo "<script type='text/javascript'>alert('$message');</script>";
        header("refresh:.1; url=index.php");
    }

}
else {
    $message = "Şifreler uyuşmuyor";
    echo "<script type='text/javascript'>alert('$message');</script>";
  
    header("refresh:.1; url=sign_up.php");
}

    














?>