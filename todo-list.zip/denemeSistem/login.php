<?php 

    session_start();

    include 'db_conn.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $k_adi = $_POST['K_Adi'];
        $k_sifre = $_POST['Sifre'];

        $stmt = $db -> prepare('SELECT * FROM kullanici WHERE K_Adi =:ad AND Sifre =:sifre');
        $stmt -> execute(array(
            'ad' => $k_adi,
            'sifre' => $k_sifre
        ));

        if ($stmt -> rowCount() > 0) {
            $user = $stmt -> fetch(PDO::FETCH_OBJ);

            $_SESSION['login'] = true;
            $_SESSION['id'] = $user -> id;

            header('Location: todo.php');
        }else {
            header('Location: index.php');
        }

    }

?>