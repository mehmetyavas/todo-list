<?php
include("db_conn.php");
session_start();
if (!isset($_SESSION["kullanici"])) {
    header("location:index.php");
}else {
        echo"admin paneli<br>";
        echo"<a href=\"logout.php\">çıkış yap</a>";
}
?>