<?php

$baglanti=mysqli_connect('localhost','admin',
'123456','to_do_list');
mysqli_set_charset($baglanti,"UTF8");
if(!$baglanti){
    echo "cart curt".mysqli_connect_error();

}



?>