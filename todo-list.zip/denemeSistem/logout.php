<?php
session_start();
ob_start();
session_unset();
echo"<center> Çıkış yaptınız. </center>";

header("refresh:1; url=index.php");

ob_end_flush();

?>