<?php
$sName="localhost";
$uName="admin";
$pass="123456";
$db_name="to_do_list";
try{
    $db=new PDO("mysql:host=$sName;dbname=$db_name",
                  $uName,$pass);
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    

}catch(PDOException $e){
    echo"connection failed: ".$e->getMessage();

}

?>