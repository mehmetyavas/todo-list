<?php 

    session_start();

    if (isset($_SESSION['login'])) {

        if (isset($_POST['title'])) {

            include dirname(__DIR__) . '/db_conn.php';

            $title = $_POST['title'];
            $user_id = $_SESSION['id'];

            $stmt = $db -> prepare('INSERT INTO todos SET user_id=:id, title=:title');
            $stmt -> execute(array('id' => $user_id, 'title' => $title));

            if ($stmt -> rowCount() > 0) {
                header('Location: ../todo.php');
            } else {
                header('Location: ' . dirname(__DIR__) . '/todo.php?mess=error');
            }

        } else {
            header('Location: ' . dirname(__DIR__) . 'todo.php?mess=error');
        }

    } else {
        header('Location: ' . dirname(__DIR__) . 'index.php');
    }

?>