<?php

    session_start();

    if (isset($_SESSION['login'])) header('Location: todo.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TODO APP</title>
    <link rel="stylesheet" href="styleIndex.css">
    
</head>
<body>
<div class="center">
    <form action="login.php" method="post" autocomplete="off">
    <div class="txt_field">
        <input type="text" name="K_Adi"required>
        <label  >Username</label><br>
    </div>
    <div class="txt_field">
        <input type="password" name="Sifre"required>
        <label >Password</label><br>
    </div>
    <div class="pass">Forgot Password?</div>
    <input type="submit" value="Login">
    <div class="signup_link">
        Not a member?<a href="sign_up.php">Signup</a>
</div>
    </form>
</div>
</body>
</html>